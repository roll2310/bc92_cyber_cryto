 console.log("Hello word")
 console.log("Hello e")

//  variables (bien) + Data types (kieu du lieu)
let bottle = "Nuoc khoang lavie";
console.log(bottle)
let firstname = "khai";
console.log(firstname)
let lastname = "Nguyen";
console.log(lastname)
let adress = "32 tien son 20";
console.log(adress)
let numberStudent = 3
console.log(numberStudent)

let isMaried = true
console.log(isMaried)

let numberChildren = null;
console.log(numberChildren);

let job; job = "Deverloper"
console.log(job)

// Cac loai toan tu
// phep cong +
let a = 5
let b = 10
let SumAB = a+b
console.log(SumAB)

// phep tru -
let c = 10  
let d = 5
let SumCD = c - d
console.log(SumCD)

// phep nhan *
let e = 10
let f = 5
let sumEF = e*f
console.log(sumEF)

// phep chia /\
let g = 10
let h = 5
let sumGH = g/h
console.log(sumGH)

// Phep chia lay du %
let i = 10
let j = 3
let sumIJ = i%j
console.log(sumIJ)

// tang gia tri bien len 1 don vi: ++

let k = 10
k++
console.log(k)

// khai bao bien: const(hang so)

const PI = 3.14;
console.log(PI)