// tinh trunh binh 5 so 
// Dau vao
// -tao bien number_1 de chua so thu 1
// -tao bien number_2 de chua so thu 2
// -tao bien number_3 de chua so thu 3
// -tao bien number_4 de chua so thu 4
// -tao bien number_5 de chua so thu 5
// -tao bien averageNumber chua gia tri trung binh: gan gia tri 0
// 
// Xu ly
// -tinh tong 5 so: lay 5 so cong lai voi nhau
// -tinh gia tri  trung binh cua 5 so: lay tong 5 so chia cho 5
// -gan gia tri trung binh vao bien avarageNumber
// -tao bien result chua ket qua hien thi
// 
// Dau ra
// -in kq ra consule/

let number_1 = 5;
let number_2 = 7;
let number_3 = 3;
let number_4 = 9;
let number_5 = 10;
let averageNumber = 0;

averageNumber = (number_1 + number_2 + number_3 + number_4 + number_5) / 5;
const result = "Gia tri trung binh cua 5 so la: " + averageNumber; 
console.log(result) 