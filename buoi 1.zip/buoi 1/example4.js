/**Đầu vào
 * -Tạo biến quy đổi nhập số USD cần đổi
 * -Tạo biến số tiền VND quy đổi
 * Xử lý
 * -Tiến hành quy đổi USD sang VND
 * Đầu ra
 * -In ra số tiền VND sau khi quy đổi
 */

let USD = Number(prompt("Nhap so tien USD can doi:"));
console.log(USD);
let VND = 23.500 
echange = 0;
echange = USD * VND

let result = echange + " 000VND";
console.log(result);