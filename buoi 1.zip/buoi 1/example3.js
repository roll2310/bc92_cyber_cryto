let number_1 = prompt   ("Nhap so thu 1:");
console.log(number_1);