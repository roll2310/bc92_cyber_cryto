// tinh tien luong cua nv
// ** Dau vao
// * - Tao bien chua gia luong theo ngay: 100000
// * - Tao bien chua so ngay lam viec cua nv
// *- Tao bien chua tong luong nv ==> gia tri = 0
// *
// *
// ** Xu ly
// Lay so ngay lam viec * luong theo ngay 
// gan gia tri cho tong luong nv
// *
// *
// dau
// In ra tong luong nv

let dailySalary = 100000;
let workingDays = 22;
let totalSalary = 0;

totalSalary = dailySalary * workingDays;

let result = "Tong luong nhan vien: " + totalSalary;
console.log(result);